 function validate() {
   if(document.getElementById("pic").value != "") {
        let label = document.getElementById("pic_label")
        label.style.background = "green";
   }
}
